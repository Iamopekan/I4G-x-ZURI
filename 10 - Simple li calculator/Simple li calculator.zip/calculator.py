Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

====== RESTART: C:/Users/Designhive/pyproj/Simple li calculator/addsub.py ======
Enter first number here 100
Enter second number here 250
Addition is = 350.0
Subtraction is = -150.0
Multiplication is = 25000.0
Division is = 0.4
