a=float(input("Enter first number here "))
b=float(input("Enter second number here "))

add=a+b
sub=a-b
mul=a*b
div=a/b

print("Addition is =", add)
print("Subtraction is =", sub)
print("Multiplication is =", mul)
print("Division is =", div)

